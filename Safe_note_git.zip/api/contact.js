// api/contact.js
// Handles submissions from the contact form

// Make sure to install the Supabase client library: npm install @supabase/supabase-js
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client securely
// These MUST be set in your serverless function's environment variables
const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY; 

// Basic check - real functions need more robust error handling/logging
if (!supabaseUrl || !supabaseKey) {
  console.error("Supabase URL or Service Role Key environment variable is not set.");
  // In a real app, you might throw an error or return a specific server error
}

const supabase = createClient(supabaseUrl, supabaseKey);

// --- Platform-Specific Handler ---
// This example uses a generic structure. Adapt it for your platform (Vercel, Netlify, etc.)
// For Vercel/Next.js: export default async function handler(req, res) { ... }
// For Netlify: exports.handler = async (event, context) => { ... }

export default async function handler(req, res) { // Example for Vercel/Next.js like structure
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).json({ message: `Method ${req.method} Not Allowed` });
  }

  try {
    const { name, email, message } = req.body;

    // Basic validation (add more as needed)
    if (!name || !email || !message) {
      return res.status(400).json({ message: 'Missing required fields (name, email, message).' });
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
        return res.status(400).json({ message: 'Invalid email format.' });
    }

    // --- Metadata Capture ---
    // IP Address (adapt based on your platform)
    // Vercel: req.headers['x-forwarded-for']?.split(',')[0] || req.socket?.remoteAddress
    // Netlify: event.headers['client-ip']
    // Cloudflare: req.headers.get('CF-Connecting-IP')
    const ip_address = req.headers['x-forwarded-for']?.split(',')[0] || req.headers['client-ip'] || req.socket?.remoteAddress || null;
    
    // Geo Location (Requires external service or platform integration)
    // Example placeholder - fetching from an external API like ip-api.com is common
    // You might need to make an async call here if using an external service
    let country = null;
    let region = null;
    let city = null;
    // if (ip_address) { 
    //    try {
    //       const geoResponse = await fetch(`http://ip-api.com/json/${ip_address}?fields=status,country,regionName,city`);
    //       const geoData = await geoResponse.json();
    //       if (geoData.status === 'success') {
    //          country = geoData.country;
    //          region = geoData.regionName;
    //          city = geoData.city;
    //       }
    //    } catch (geoError) {
    //       console.error("Geolocation lookup failed:", geoError); 
    //       // Decide if you want to proceed without geo data or return an error
    //    }
    // }

    // --- Insert into Supabase ---
    const { data, error } = await supabase
      .from('contact_submissions')
      .insert([
        { 
          name, 
          email, 
          message, 
          ip_address, // Add captured metadata
          country,    // Add captured metadata
          region,     // Add captured metadata
          city        // Add captured metadata
        }
      ])
      .select(); // Use .select() if you want the inserted data back

    if (error) {
      console.error('Supabase Insert Error:', error);
      // Don't expose detailed database errors to the client
      return res.status(500).json({ message: 'Error saving submission.' });
    }

    // --- Success Response ---
    console.log('Contact submission saved:', data); 
    return res.status(200).json({ message: 'Message received successfully!' });

  } catch (error) {
    console.error('API Route Error:', error);
    return res.status(500).json({ message: 'An unexpected error occurred.' });
  }
} 