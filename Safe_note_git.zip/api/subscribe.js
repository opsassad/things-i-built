// api/subscribe.js
// Handles submissions from the newsletter forms

import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client securely (reuse from contact.js logic)
const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY; 

if (!supabaseUrl || !supabaseKey) {
  console.error("Supabase URL or Service Role Key environment variable is not set.");
}

const supabase = createClient(supabaseUrl, supabaseKey);

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).json({ message: `Method ${req.method} Not Allowed` });
  }

  try {
    // The form might send 'email' and optionally 'name'
    const { email, name } = req.body; 

    // Basic validation
    if (!email) {
      return res.status(400).json({ message: 'Email is required.' });
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
        return res.status(400).json({ message: 'Invalid email format.' });
    }

    // --- Metadata Capture (same as contact.js) ---
    const ip_address = req.headers['x-forwarded-for']?.split(',')[0] || req.headers['client-ip'] || req.socket?.remoteAddress || null;
    let country = null;
    let region = null;
    let city = null;
    // Optional: Add geo-location lookup here if desired
    // See contact.js for example placeholder

    // --- Insert into Supabase ---
    // Use upsert to handle potential duplicate email signups gracefully 
    // (updates existing record if email matches, otherwise inserts)
    // If you want duplicates to fail, use .insert() instead.
    const { data, error } = await supabase
      .from('newsletter_subscriptions')
      .upsert(
        { 
          email, 
          name: name || null, // Use provided name or null if empty
          ip_address,  
          country,    
          region,     
          city,       
          subscription_status: 'active' // Set status on signup/upsert
        },
        { onConflict: 'email' } // Specify the constraint column for upsert
      )
      .select(); 

    if (error) {
      console.error('Supabase Upsert Error:', error);
       // Handle potential unique constraint violation if not using upsert
      if (error.code === '23505') { // Postgres unique violation code
          return res.status(409).json({ message: 'Email already subscribed.' });
      }
      return res.status(500).json({ message: 'Error processing subscription.' });
    }

    // --- Success Response ---
    console.log('Newsletter subscription saved/updated:', data);
    return res.status(200).json({ message: 'Subscription successful!' });

  } catch (error) {
    console.error('API Route Error:', error);
    return res.status(500).json({ message: 'An unexpected error occurred.' });
  }
} 