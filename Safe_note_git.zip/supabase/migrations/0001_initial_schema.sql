-- Initial Schema Migration

-- Enable HTTP extension if not already enabled (often needed for Supabase features)
-- create extension if not exists http with schema extensions;

-- Enable pgcrypto extension for UUID generation if needed
-- create extension if not exists pgcrypto with schema extensions;

-- Create home_page_content table
CREATE TABLE public.home_page_content (
    id bigint PRIMARY KEY DEFAULT 1, -- Assuming a single row with fixed ID 1
    hero_title text,
    hero_subtitle text,
    about_text text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    -- Ensure only one row can exist with id = 1
    CONSTRAINT home_page_content_singleton CHECK (id = 1)
);

-- Create site_settings table
CREATE TABLE public.site_settings (
    id bigint PRIMARY KEY DEFAULT 1, -- Assuming a single row with fixed ID 1
    site_title text,
    site_description text,
    github_url text,
    linkedin_url text,
    twitter_url text,
    enable_comments boolean DEFAULT true NOT NULL,
    enable_analytics boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    -- Ensure only one row can exist with id = 1
    CONSTRAINT site_settings_singleton CHECK (id = 1)
);

-- Create blog_posts table
CREATE TABLE public.blog_posts (
    id text PRIMARY KEY, -- e.g., 'blog/my-slug' or 'project/my-project'
    title text NOT NULL,
    excerpt text,
    content text,
    category text,
    tags jsonb, -- Using jsonb for flexibility
    date timestamp with time zone, -- Consider renaming for clarity (e.g., published_at)
    read_time text,
    author_name text,
    author_role text,
    technologies jsonb,
    features jsonb,
    detailed_description text,
    image_url text,
    featured_image text,
    author_image text,
    link text,
    is_draft boolean DEFAULT false NOT NULL,
    slug text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL, -- e.g., 'draft', 'published', 'archived'
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    view_count integer DEFAULT 0 NOT NULL,
    like_count integer DEFAULT 0 NOT NULL,
    seo_score integer
);

-- Optional: Add an index for faster slug lookup if needed
-- CREATE INDEX idx_blog_posts_slug ON public.blog_posts(slug);

-- Function to automatically update 'updated_at' timestamp
CREATE OR REPLACE FUNCTION public.handle_updated_at() 
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update 'updated_at' on blog_posts modification
CREATE TRIGGER on_blog_post_update
  BEFORE UPDATE ON public.blog_posts
  FOR EACH ROW
  EXECUTE PROCEDURE public.handle_updated_at();


-- Row Level Security (RLS) Policies --

-- Enable RLS for the tables
ALTER TABLE public.home_page_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;

-- Policy: Allow public read access to home_page_content
CREATE POLICY "Allow public read access" ON public.home_page_content
  FOR SELECT USING (true);

-- Policy: Allow public read access to site_settings
CREATE POLICY "Allow public read access" ON public.site_settings
  FOR SELECT USING (true);

-- Policy: Allow public read access to published blog posts
CREATE POLICY "Allow public read access for published posts" ON public.blog_posts
  FOR SELECT USING (status = 'published' AND is_draft = false);

-- WARNING: The following policies allow ANY anonymous user to modify data.
-- This is generally UNSAFE for production without proper authentication and authorization checks.
-- These are included TEMPORARILY based on the request to not implement auth yet.
-- Replace these with authenticated policies as soon as possible.

-- Policy: Allow anonymous users to update home_page_content (UNSAFE)
CREATE POLICY "Allow anon update" ON public.home_page_content
  FOR UPDATE USING (true) WITH CHECK (true);

-- Policy: Allow anonymous users to update site_settings (UNSAFE)
CREATE POLICY "Allow anon update" ON public.site_settings
  FOR UPDATE USING (true) WITH CHECK (true);

-- Policy: Allow anonymous users to insert/update/delete blog posts (UNSAFE)
CREATE POLICY "Allow anon modifications" ON public.blog_posts
  FOR ALL USING (true) WITH CHECK (true); -- Allows INSERT, UPDATE, DELETE


-- Seed initial data (Optional but recommended) --

-- Seed home_page_content (only if table is empty)
INSERT INTO public.home_page_content (id, hero_title, hero_subtitle, about_text)
SELECT 1, 'Repeat', 'Building intelligent applications that solve complex business challenges', 'I''m a fullstack developer specializing in AI-powered applications and Google Workspace automation. With a focus on creating practical solutions for businesses, I build tools that enhance productivity and streamline workflows.'
WHERE NOT EXISTS (SELECT 1 FROM public.home_page_content WHERE id = 1);

-- Seed site_settings (only if table is empty)
INSERT INTO public.site_settings (id, site_title, site_description, github_url, linkedin_url, twitter_url, enable_comments, enable_analytics)
SELECT 1, 'Repeat', 'Professional portfolio of ASSAD, a fullstack developer specializing in AI-powered applications and Google Workspace automation.', 'https://github.com', 'https://linkedin.com', 'https://twitter.com', true, true
WHERE NOT EXISTS (SELECT 1 FROM public.site_settings WHERE id = 1);

-- Note: Blog posts seeding is usually more complex and might be better handled via a separate script or manually. 

-- Create media_library table
CREATE TABLE public.media_library (
    id text PRIMARY KEY, -- e.g., 'media-1746218490050' or a generated UUID
    name text NOT NULL,
    url text NOT NULL, -- Store the full public Supabase URL
    size text,
    type text,
    bucket text,
    path text, -- The path within the Supabase storage bucket
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

-- Optional: Add indexes for faster lookup if needed, e.g., by path or bucket
-- CREATE INDEX idx_media_library_path ON public.media_library(path);

-- Enable RLS for the media_library table
ALTER TABLE public.media_library ENABLE ROW LEVEL SECURITY;

-- Policy: Allow public read access to media_library
CREATE POLICY "Allow public read access" ON public.media_library
  FOR SELECT USING (true);

-- Policy: Allow anonymous users to insert/update/delete media library entries (UNSAFE - Placeholder)
-- Replace with authenticated policies later
CREATE POLICY "Allow anon modifications" ON public.media_library
  FOR ALL USING (true) WITH CHECK (true); -- Allows INSERT, UPDATE, DELETE

-- Comment indicating that this table stores metadata for files in Supabase Storage
COMMENT ON TABLE public.media_library IS 'Stores metadata for files uploaded to Supabase Storage.';


-- ==== Newsletter Subscriptions Table Creation ====
-- Migration: Add newsletter_subscriptions and contact_submissions tables

-- ==== Newsletter Subscriptions Table ====

CREATE TABLE public.newsletter_subscriptions (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    email text NOT NULL UNIQUE CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'), -- Mandatory, unique, basic format check
    name text, -- Optional
    subscription_status text NOT NULL DEFAULT 'active', -- e.g., 'active', 'unsubscribed'
    ip_address text, -- Captured metadata
    country text,    -- Captured metadata
    region text,     -- Captured metadata (maps to regionName)
    city text,       -- Captured metadata
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL -- For status changes
);

COMMENT ON TABLE public.newsletter_subscriptions IS 'Stores email addresses and optional names for newsletter signups.';
COMMENT ON COLUMN public.newsletter_subscriptions.email IS 'Subscriber email address.';
COMMENT ON COLUMN public.newsletter_subscriptions.name IS 'Optional subscriber name.';
COMMENT ON COLUMN public.newsletter_subscriptions.subscription_status IS 'Current status (e.g., active, unsubscribed).';
COMMENT ON COLUMN public.newsletter_subscriptions.ip_address IS 'IP address recorded at signup.';
COMMENT ON COLUMN public.newsletter_subscriptions.country IS 'Country recorded at signup.';
COMMENT ON COLUMN public.newsletter_subscriptions.region IS 'Region/State recorded at signup.';
COMMENT ON COLUMN public.newsletter_subscriptions.city IS 'City recorded at signup.';

-- Function to automatically update 'updated_at' timestamp (if not already created)
-- Ensure this function exists or create it separately if needed.
-- CREATE OR REPLACE FUNCTION public.handle_updated_at() ...

-- Trigger to update 'updated_at' on newsletter_subscriptions modification
CREATE TRIGGER on_newsletter_subscription_update
  BEFORE UPDATE ON public.newsletter_subscriptions
  FOR EACH ROW
  EXECUTE PROCEDURE public.handle_updated_at();

-- Index for faster email lookups
CREATE INDEX idx_newsletter_subscriptions_email ON public.newsletter_subscriptions(email);

-- ==== Contact Form Submissions Table ====

CREATE TABLE public.contact_submissions (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    name text NOT NULL, -- Sender's name from form
    email text NOT NULL CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'), -- Sender's email, basic format check
    message text NOT NULL, -- Message content from form
    ip_address text, -- Captured metadata
    country text,    -- Captured metadata
    region text,     -- Captured metadata (maps to regionName)
    city text,       -- Captured metadata
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

COMMENT ON TABLE public.contact_submissions IS 'Stores submissions from the contact form.';
COMMENT ON COLUMN public.contact_submissions.name IS 'Name provided in the contact form.';
COMMENT ON COLUMN public.contact_submissions.email IS 'Email address provided in the contact form.';
COMMENT ON COLUMN public.contact_submissions.message IS 'Message content from the contact form.';
COMMENT ON COLUMN public.contact_submissions.ip_address IS 'IP address recorded at submission.';
COMMENT ON COLUMN public.contact_submissions.country IS 'Country recorded at submission.';
COMMENT ON COLUMN public.contact_submissions.region IS 'Region/State recorded at submission.';
COMMENT ON COLUMN public.contact_submissions.city IS 'City recorded at submission.';

-- Optional: Index for searching by email or date
-- CREATE INDEX idx_contact_submissions_email ON public.contact_submissions(email);
-- CREATE INDEX idx_contact_submissions_created_at ON public.contact_submissions(created_at);


-- ==== Row Level Security (RLS) Policies ====

-- Enable RLS for the new tables
ALTER TABLE public.newsletter_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_submissions ENABLE ROW LEVEL SECURITY;

-- Allow public insert access for newsletter subscriptions (for signup form)
DROP POLICY IF EXISTS "Allow public insert" ON public.newsletter_subscriptions;
CREATE POLICY "Allow public insert" ON public.newsletter_subscriptions
  FOR INSERT
  TO public -- Allows anyone, including anonymous users
  WITH CHECK (true); -- No specific check required for insertion itself

-- Allow public insert access for contact submissions (for contact form)
DROP POLICY IF EXISTS "Allow public insert" ON public.contact_submissions;
CREATE POLICY "Allow public insert" ON public.contact_submissions
  FOR INSERT
  TO public -- Allows anyone, including anonymous users
  WITH CHECK (true); -- No specific check required for insertion itself

-- NOTE: SELECT, UPDATE, DELETE policies are intentionally omitted for the 'public' role.
-- Access for reading or managing these records should be granted to specific authenticated roles (e.g., 'authenticated', 'service_role', or custom admin roles).
-- Example (Admin read access - DO NOT APPLY unless intended):
-- CREATE POLICY "Allow admin read access" ON public.newsletter_subscriptions FOR SELECT TO service_role USING (true);
-- CREATE POLICY "Allow admin read access" ON public.contact_submissions FOR SELECT TO service_role USING (true);
