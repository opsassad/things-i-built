import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function generateSlug(title: string, type: 'blog' | 'project' = 'blog'): string {
  // Convert to lowercase and replace spaces and special characters with hyphens
  const baseSlug = title
    .toLowerCase()
    // Replace special characters with spaces
    .replace(/[^a-z0-9\s-]/g, '')
    // Replace multiple spaces with single space
    .replace(/\s+/g, ' ')
    .trim()
    // Replace spaces with hyphens
    .replace(/\s/g, '-');
  
  // Add prefix based on type
  return `${type}/${baseSlug}`;
}

// Function to ensure unique slug
export function ensureUniqueSlug(
  baseSlug: string, 
  existingSlugs: string[]
): string {
  let slug = baseSlug;
  let counter = 1;
  
  while (existingSlugs.includes(slug)) {
    slug = `${baseSlug}-${counter}`;
    counter++;
  }
  
  return slug;
}
