import { ArrowRight } from "lucide-react";
import { useState } from "react";

const StayUpdated = () => {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setMessage("");

    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      setMessage("Please enter a valid email address.");
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await fetch('/api/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, ...(name && { name }) }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || 'Subscription failed. Please try again.');
      }

      setMessage(result.message || "Thank you for subscribing!");
      setEmail("");
      setName("");
      
    } catch (error: any) {
      setMessage(error.message || "An error occurred.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-24 relative overflow-hidden">
      {/* Gradient Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-b from-purple-50/30 via-pink-50/20 to-transparent"></div>
        <div className="absolute top-0 -right-1/2 w-[800px] h-[800px] bg-purple-100 rounded-full mix-blend-multiply filter blur-[96px] opacity-20 animate-blob"></div>
        <div className="absolute -bottom-1/4 left-1/4 w-[600px] h-[600px] bg-pink-100 rounded-full mix-blend-multiply filter blur-[64px] opacity-20 animate-blob animation-delay-2000"></div>
      </div>

      <div className="container-custom relative">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-600">
              Stay Updated
            </h2>
            <p className="text-lg text-zinc-600">
              Get exclusive insights on AI, automation, and tech trends delivered straight to your inbox.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-sm border border-zinc-100/10 rounded-2xl p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
              <div>
                <h3 className="text-xl font-semibold mb-4 text-zinc-800">
                  What you'll receive:
                </h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-zinc-900 flex items-center justify-center mt-1">
                      <div className="w-2 h-2 rounded-full bg-white"></div>
                    </div>
                    <span className="text-zinc-600">Weekly insights on emerging AI technologies</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-zinc-900 flex items-center justify-center mt-1">
                      <div className="w-2 h-2 rounded-full bg-white"></div>
                    </div>
                    <span className="text-zinc-600">Practical automation strategies and tutorials</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-zinc-900 flex items-center justify-center mt-1">
                      <div className="w-2 h-2 rounded-full bg-white"></div>
                    </div>
                    <span className="text-zinc-600">Early access to new projects and tools</span>
                  </li>
                </ul>
              </div>

              <div>
                <form className="space-y-4" onSubmit={handleSubmit}>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-zinc-700 mb-1">
                      Email address
                    </label>
                    <input
                      type="email"
                      id="email"
                      placeholder="you@example.com"
                      className="w-full px-4 py-2 rounded-lg border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-zinc-200 transition-all"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-zinc-700 mb-1">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      placeholder="Your name"
                      className="w-full px-4 py-2 rounded-lg border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-zinc-200 transition-all"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-zinc-900 hover:bg-zinc-800 text-white px-6 py-3 rounded-lg transition-colors flex items-center justify-center gap-2 group disabled:opacity-60"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Subscribing..." : "Subscribe to newsletter"}
                    {!isSubmitting && <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />}
                  </button>
                </form>
                <p className="mt-4 text-sm text-zinc-500 text-center">
                  {message ? message : "No spam, unsubscribe at any time."}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StayUpdated; 