import { useState, useEffect } from "react";
import {
  FileText,
  Eye,
  Star,
  Activity,
  Search,
  BookOpen,
  Briefcase,
  Pencil,
  Check,
  Save,
  TrendingUp,
  BarChart2,
  ThumbsUp,
  Award,
  TrendingDown,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { useContent } from "../../context/ContentContext";
import { Chart } from "../ui/chart";
import { Timeline, TimelineItem } from "../ui/timeline";
import { StatsCard } from "../ui/stats-card";
import { Progress } from "../ui/progress";
import { cn } from "../../lib/utils";

interface ViewStats {
  date: string;
  views: number;
}

interface ContentStats {
  title: string;
  views: number;
  likes: number;
  category: string;
}

interface RatingDistribution {
  stars: number;
  count: number;
  percentage: number;
}

interface ContentRanking {
  title: string;
  category: string;
  score: number;
  trend: 'up' | 'down' | 'neutral';
  engagement: number;
}

const DashboardAnalytics = () => {
  const { blogPosts } = useContent();
  const [viewStats, setViewStats] = useState<ViewStats[]>([]);
  const [popularContent, setPopularContent] = useState<ContentStats[]>([]);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [ratingDistribution, setRatingDistribution] = useState<RatingDistribution[]>([]);
  const [contentRanking, setContentRanking] = useState<ContentRanking[]>([]);

  // Calculate content statistics
  const totalPosts = blogPosts.length;
  const publishedPosts = blogPosts.filter(post => post.status === "published").length;
  const draftPosts = blogPosts.filter(post => post.status === "draft").length;
  const projectPosts = blogPosts.filter(post => post.category === "Project").length;
  const blogArticles = totalPosts - projectPosts;

  // Mock data for view statistics (replace with real data later)
  useEffect(() => {
    const mockViewStats = [
      { date: "Mon", views: 120 },
      { date: "Tue", views: 150 },
      { date: "Wed", views: 180 },
      { date: "Thu", views: 190 },
      { date: "Fri", views: 220 },
      { date: "Sat", views: 250 },
      { date: "Sun", views: 280 },
    ];
    setViewStats(mockViewStats);

    const mockPopularContent = blogPosts
      .slice(0, 5)
      .map(post => ({
        title: post.title,
        views: Math.floor(Math.random() * 1000),
        likes: Math.floor(Math.random() * 100),
        category: post.category
      }));
    setPopularContent(mockPopularContent);

    const mockActivity = [
      { type: "edit", content: "Updated Project: AI Canvas", time: "2 hours ago" },
      { type: "publish", content: "Published: Getting Started with React", time: "5 hours ago" },
      { type: "draft", content: "Saved draft: TypeScript Best Practices", time: "1 day ago" },
      { type: "view", content: "100 views milestone: Python Tutorial", time: "2 days ago" },
    ];
    setRecentActivity(mockActivity);

    // Mock rating distribution
    const mockRatingDistribution: RatingDistribution[] = [
      { stars: 5, count: 245, percentage: 68 },
      { stars: 4, count: 82, percentage: 20 },
      { stars: 3, count: 25, percentage: 7 },
      { stars: 2, count: 12, percentage: 3 },
      { stars: 1, count: 8, percentage: 2 },
    ];
    setRatingDistribution(mockRatingDistribution);

    // Mock content ranking
    const mockContentRanking: ContentRanking[] = [
      {
        title: "AI Document Analyzer",
        category: "Project",
        score: 98,
        trend: "up",
        engagement: 85,
      },
      {
        title: "Getting Started with React",
        category: "Article",
        score: 92,
        trend: "up",
        engagement: 78,
      },
      {
        title: "Python Tutorial",
        category: "Article",
        score: 87,
        trend: "neutral",
        engagement: 72,
      },
      {
        title: "Smart Email Manager",
        category: "Project",
        score: 85,
        trend: "down",
        engagement: 65,
      },
    ];
    setContentRanking(mockContentRanking);
  }, [blogPosts]);

  const averageRating = ratingDistribution.reduce((acc, curr) => 
    acc + (curr.stars * curr.count), 0) / 
    ratingDistribution.reduce((acc, curr) => acc + curr.count, 0);

  return (
    <div className="space-y-8">
      {/* Overview Stats */}
      <div className="grid gap-4 sm:gap-6 grid-cols-2 md:grid-cols-4">
        <StatsCard
          icon={<FileText className="h-6 w-6 text-muted-foreground" />}
          title="Total Content"
          value={totalPosts}
          description={`${blogArticles} articles, ${projectPosts} projects`}
          className="bg-white dark:bg-zinc-800/50"
        />
        <StatsCard
          icon={<Activity className="h-6 w-6 text-muted-foreground" />}
          title="Published"
          value={publishedPosts}
          description={`${draftPosts} drafts pending`}
          className="bg-white dark:bg-zinc-800/50"
        />
        <StatsCard
          icon={<Eye className="h-6 w-6 text-muted-foreground" />}
          title="Total Views"
          value="10.2K"
          description="+180 from last week"
          className="bg-white dark:bg-zinc-800/50"
        />
        <StatsCard
          icon={<Search className="h-6 w-6 text-muted-foreground" />}
          title="SEO Score"
          value="85"
          description="+5 from last month"
          className="bg-white dark:bg-zinc-800/50"
        />
      </div>

      {/* Main Content */}
      <div className="grid gap-4 sm:gap-6 md:grid-cols-2">
        {/* View Statistics */}
        <Chart
          title="View Statistics"
          data={viewStats}
          xKey="date"
          yKey="views"
          className="bg-white dark:bg-zinc-800/50 rounded-lg border p-4"
        />

        {/* Popular Content */}
        <Card className="bg-white dark:bg-zinc-800/50">
          <CardHeader>
            <CardTitle className="text-base font-medium">Popular Content</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {popularContent.slice(0, 4).map((content, index) => (
                <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-zinc-50 dark:bg-zinc-800/80">
                  <div className="flex-none">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full border bg-white dark:bg-zinc-700">
                      {content.category === "Project" ? (
                        <Briefcase className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <BookOpen className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {content.title}
                    </p>
                    <div className="flex items-center gap-3 mt-1">
                      <p className="text-xs text-muted-foreground">
                        {content.views.toLocaleString()} views
                      </p>
                      <div className="flex items-center gap-1">
                        <Star className="h-3 w-3 text-amber-400" />
                        <span className="text-xs text-muted-foreground">
                          {content.likes}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Rating Analysis */}
        <Card className="bg-white dark:bg-zinc-800/50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base font-medium">Rating Analysis</CardTitle>
              <div className="flex items-center gap-2">
                <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                <span className="text-lg font-bold">{averageRating.toFixed(1)}</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {ratingDistribution.map((rating) => (
                <div key={rating.stars} className="grid grid-cols-12 items-center gap-3">
                  <div className="col-span-2 flex items-center gap-1.5">
                    <span className="text-sm font-medium">{rating.stars}</span>
                    <Star className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="col-span-8">
                    <Progress 
                      value={rating.percentage} 
                      className="h-2 bg-zinc-100 dark:bg-zinc-700" 
                      indicatorClassName="bg-blue-500/50 dark:bg-blue-400/50" 
                    />
                  </div>
                  <div className="col-span-2 text-right">
                    <span className="text-sm text-muted-foreground">
                      {rating.count}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Content Ranking */}
        <Card className="bg-white dark:bg-zinc-800/50">
          <CardHeader>
            <CardTitle className="text-base font-medium">Content Ranking</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {contentRanking.map((content, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/50">
                    {content.category === "Project" ? (
                      <Briefcase className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <BookOpen className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">{content.title}</p>
                      <div className="flex items-center gap-2">
                        {content.trend === "up" && (
                          <TrendingUp className="h-4 w-4 text-emerald-500/70" />
                        )}
                        {content.trend === "down" && (
                          <TrendingDown className="h-4 w-4 text-rose-500/70" />
                        )}
                        {content.trend === "neutral" && (
                          <Activity className="h-4 w-4 text-amber-500/70" />
                        )}
                        <span className="text-sm font-medium">{content.score}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1">
                        <Award className="h-3.5 w-3.5 text-muted-foreground/60" />
                        <span className="text-xs text-muted-foreground">
                          Rank #{index + 1}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <BarChart2 className="h-3.5 w-3.5 text-muted-foreground/60" />
                        <span className="text-xs text-muted-foreground">
                          {content.engagement}% engagement
                        </span>
                      </div>
                    </div>
                    <Progress 
                      value={content.score} 
                      className="h-1 bg-muted/30" 
                      indicatorClassName={cn(
                        "transition-all",
                        content.trend === "up" ? "bg-emerald-500/20" :
                        content.trend === "down" ? "bg-rose-500/20" :
                        "bg-amber-500/20"
                      )}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="col-span-2 bg-white dark:bg-zinc-800/50">
          <CardHeader>
            <CardTitle className="text-base font-medium">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <Timeline>
              {recentActivity.map((activity, index) => {
                let icon;
                switch (activity.type) {
                  case "edit":
                    icon = <Pencil className="h-4 w-4 text-muted-foreground" />;
                    break;
                  case "publish":
                    icon = <Check className="h-4 w-4 text-muted-foreground" />;
                    break;
                  case "draft":
                    icon = <Save className="h-4 w-4 text-muted-foreground" />;
                    break;
                  case "view":
                    icon = <TrendingUp className="h-4 w-4 text-muted-foreground" />;
                    break;
                }

                return (
                  <TimelineItem
                    key={index}
                    icon={icon}
                    title={activity.content}
                    time={activity.time}
                    className="py-2 first:pt-0 last:pb-0"
                  >
                    <div className="flex items-center gap-2 mt-1">
                      {activity.type === "edit" && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400">
                          Edited
                        </span>
                      )}
                      {activity.type === "publish" && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                          Published
                        </span>
                      )}
                      {activity.type === "draft" && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
                          Draft
                        </span>
                      )}
                      {activity.type === "view" && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400">
                          Milestone
                        </span>
                      )}
                    </div>
                  </TimelineItem>
                );
              })}
            </Timeline>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DashboardAnalytics; 