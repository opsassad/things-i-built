import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Image from '@tiptap/extension-image';
import Typography from '@tiptap/extension-typography';
import Placeholder from '@tiptap/extension-placeholder';
import Link from '@tiptap/extension-link';
import Underline from '@tiptap/extension-underline';
import TextAlign from '@tiptap/extension-text-align';
import { useState, useEffect, useCallback } from 'react';
import { Button } from '../ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs';
import { useContent } from '../../context/ContentContext';
import { toast } from '../../hooks/use-toast';
import { Separator } from '../ui/separator';
import { Bold, Italic, Underline as UnderlineIcon, AlignLeft, AlignCenter, AlignRight, ListOrdered, Image as ImageIcon, Link as LinkIcon } from 'lucide-react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  readOnly?: boolean;
}

const RichTextEditor = ({ value, onChange, placeholder, readOnly = false }: RichTextEditorProps) => {
  const { mediaLibrary, isEditMode } = useContent();
  const [showImageSelector, setShowImageSelector] = useState(false);
  const [editorMode, setEditorMode] = useState<'edit' | 'preview'>('edit');
  const [mounted, setMounted] = useState(false);

  const editor = useEditor({
    extensions: [
      StarterKit,
      Typography,
      Image.configure({
        HTMLAttributes: {
          class: 'rounded-md max-w-full h-auto',
        },
      }),
      Link.configure({
        openOnClick: false,
      }),
      Underline,
      TextAlign.configure({
        types: ['heading', 'paragraph'],
        alignments: ['left', 'center', 'right'],
        defaultAlignment: 'left',
      }),
      Placeholder.configure({
        placeholder: placeholder || 'Write something...',
      }),
    ],
    content: value,
    editable: !readOnly && isEditMode,
    onUpdate: ({ editor }) => {
      const html = editor.getHTML();
      onChange(html);
    },
    autofocus: true,
  });

  // Update editor content when value prop changes
  useEffect(() => {
    if (editor && value !== editor.getHTML()) {
      editor.commands.setContent(value || '');
    }
  }, [value, editor]);

  // Update editor editability when readOnly or isEditMode changes
  useEffect(() => {
    if (editor) {
      editor.setEditable(!readOnly && isEditMode);
    }
  }, [editor, readOnly, isEditMode]);

  useEffect(() => {
    setMounted(true);
  }, []);

  const insertImage = useCallback((url: string) => {
    if (!editor) return;

    // Insert the image at the current cursor position
    editor
      .chain()
      .focus()
      .setImage({ 
        src: url,
        alt: 'Inserted image',
      })
      .run();
    
    setShowImageSelector(false);
    
    toast({
      title: "Image Inserted",
      description: "The image has been added to your content.",
      variant: "default",
    });
  }, [editor]);

  const handleImageButtonClick = useCallback((e: React.MouseEvent) => {
    e.preventDefault(); // Prevent any default behavior
    e.stopPropagation(); // Stop event propagation
    
    if (!readOnly && isEditMode) {
      setShowImageSelector(prev => !prev);
    }
  }, [readOnly, isEditMode]);

  if (!mounted) {
    return <div className="min-h-[300px] bg-white border rounded-md p-4">Loading editor...</div>;
  }

  return (
    <div className="rich-text-editor">
      <Tabs 
        value={editorMode} 
        onValueChange={(value) => setEditorMode(value as 'edit' | 'preview')}
        className="mb-4"
      >
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="edit" className="flex items-center gap-2">
            <Bold size={16} />
            Editor
          </TabsTrigger>
          <TabsTrigger value="preview" className="flex items-center gap-2">
            <AlignLeft size={16} />
            Preview
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="edit" className="mt-0">
          <div className="bg-white border rounded-md mb-3">
            <div className="flex items-center gap-1 p-2 flex-wrap border-b">
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0"
                onClick={() => editor?.chain().focus().toggleBold().run()}
                data-active={editor?.isActive('bold')}
                disabled={!isEditMode || readOnly}
              >
                <Bold size={16} />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0"
                onClick={() => editor?.chain().focus().toggleItalic().run()}
                data-active={editor?.isActive('italic')}
                disabled={!isEditMode || readOnly}
              >
                <Italic size={16} />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0"
                onClick={() => editor?.chain().focus().toggleUnderline().run()}
                data-active={editor?.isActive('underline')}
                disabled={!isEditMode || readOnly}
              >
                <UnderlineIcon size={16} />
              </Button>
              <Separator orientation="vertical" className="h-6 mx-1" />
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0"
                onClick={() => editor?.chain().focus().setTextAlign('left').run()}
                data-active={editor?.isActive({ textAlign: 'left' })}
                disabled={!isEditMode || readOnly}
              >
                <AlignLeft size={16} />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0"
                onClick={() => editor?.chain().focus().setTextAlign('center').run()}
                data-active={editor?.isActive({ textAlign: 'center' })}
                disabled={!isEditMode || readOnly}
              >
                <AlignCenter size={16} />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0"
                onClick={() => editor?.chain().focus().setTextAlign('right').run()}
                data-active={editor?.isActive({ textAlign: 'right' })}
                disabled={!isEditMode || readOnly}
              >
                <AlignRight size={16} />
              </Button>
              <Separator orientation="vertical" className="h-6 mx-1" />
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0"
                onClick={() => editor?.chain().focus().toggleOrderedList().run()}
                data-active={editor?.isActive('orderedList')}
                disabled={!isEditMode || readOnly}
              >
                <ListOrdered size={16} />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0"
                onClick={handleImageButtonClick}
                disabled={!isEditMode || readOnly}
                type="button"
              >
                <ImageIcon size={16} />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0"
                onClick={() => {
                  if (!editor || !isEditMode || readOnly) return;
                  const url = window.prompt('Enter the URL:');
                  if (url) {
                    editor.chain().focus().setLink({ href: url }).run();
                  }
                }}
                data-active={editor?.isActive('link')}
                disabled={!isEditMode || readOnly}
              >
                <LinkIcon size={16} />
              </Button>
            </div>
            <div className={`p-4 min-h-[200px] ${readOnly || !isEditMode ? 'opacity-80' : ''}`}>
              <EditorContent editor={editor} className="prose prose-zinc max-w-none" />
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="preview" className="mt-0">
          <div className="bg-white border rounded-md p-6 min-h-[300px] prose prose-zinc max-w-none">
            <div 
              className="preview-content" 
              dangerouslySetInnerHTML={{ __html: value || '' }} 
            />
            {!value && (
              <p className="text-gray-400 italic">No content to preview yet.</p>
            )}
          </div>
        </TabsContent>
      </Tabs>
      
      {showImageSelector && (
        <div className="mt-4 border rounded-lg p-4 bg-gray-50">
          <div className="flex justify-between items-center mb-3">
            <h3 className="font-medium">Select an image</h3>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => setShowImageSelector(false)}
              type="button"
            >
              Close
            </Button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-h-60 overflow-y-auto">
            {mediaLibrary.map(image => (
              <div 
                key={image.id}
                className="aspect-square bg-white border rounded-md overflow-hidden hover:border-zinc-400 cursor-pointer transition-colors"
                onClick={() => insertImage(image.url)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    insertImage(image.url);
                  }
                }}
              >
                <img 
                  src={image.url} 
                  alt={image.name} 
                  className="w-full h-full object-cover" 
                />
              </div>
            ))}
            
            {mediaLibrary.length === 0 && (
              <div className="col-span-4 p-8 text-center text-zinc-500">
                No images available. Add images in the Media Library.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default RichTextEditor;
