import { useState, useEffect } from "react";
import { 
  Plus, 
  Trash2, 
  Edit, 
  Link as LinkIcon, 
  Eye,
  Check,
  Briefcase,
  BookOpen,
  Save
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { toast } from "../../hooks/use-toast";
import { useContent } from "../../context/ContentContext";
import RichTextEditor from "./RichTextEditor";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../ui/tabs";
import { ExtendedBlogPostType } from "../../types/content-types";
import { generateSlug, ensureUniqueSlug } from "../../lib/utils";

interface BlogEditorProps {
  type?: 'blog' | 'project';
}

// Draft interface matching the editor state
interface EditorDraft {
  id: string | null;
  title: string;
  content: string;
  excerpt: string;
  category: string;
  tags: string[];
  featuredImage: string;
  authorName: string;
  authorRole: string;
  authorImage: string;
  readTime: string;
  features: string[];
  technologies: string[];
  lastModified: number;
}

const BlogEditor = ({ type = 'blog' }: BlogEditorProps) => {
  const { blogPosts, saveBlogPost, deleteBlogPost, isEditMode } = useContent();
  
  // Filter posts by type (category)
  const filteredPosts = blogPosts.filter(post => 
    type === 'project' 
      ? post.category === 'Project'
      : post.category !== 'Project'
  );
  
  const [selectedPost, setSelectedPost] = useState<ExtendedBlogPostType | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [category, setCategory] = useState(type === 'project' ? 'Project' : 'Technology');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [featuredImage, setFeaturedImage] = useState("");
  const [authorName, setAuthorName] = useState("ASSAD");
  const [authorRole, setAuthorRole] = useState("AI & Automation Expert");
  const [authorImage, setAuthorImage] = useState("");
  const [readTime, setReadTime] = useState("5 min read");
  
  // Project-specific fields
  const [features, setFeatures] = useState<string[]>([]);
  const [featureInput, setFeatureInput] = useState("");
  const [technologies, setTechnologies] = useState<string[]>([]);
  const [techInput, setTechInput] = useState("");
  
  // UI state
  const [editorMode, setEditorMode] = useState<'edit' | 'preview'>('edit');
  const [hasDraft, setHasDraft] = useState(false);
  
  // Draft management functions
  const getDraftKey = (postId: string | null) => {
    return `blog_draft_${type}_${postId || 'new'}`;
  };
  
  const saveDraft = () => {
    if (!isEditMode) return;
    
    const draft: EditorDraft = {
      id: selectedPost?.id || null,
      title,
      content,
      excerpt,
      category,
      tags,
      featuredImage,
      authorName,
      authorRole,
      authorImage,
      readTime,
      features,
      technologies,
      lastModified: Date.now()
    };
    
    localStorage.setItem(getDraftKey(draft.id), JSON.stringify(draft));
    setHasDraft(true);
  };
  
  const loadDraft = (postId: string | null) => {
    const draftKey = getDraftKey(postId);
    const savedDraft = localStorage.getItem(draftKey);
    
    if (savedDraft) {
      try {
        const draft: EditorDraft = JSON.parse(savedDraft);
        setTitle(draft.title);
        setContent(draft.content);
        setExcerpt(draft.excerpt);
        setCategory(draft.category);
        setTags(draft.tags);
        setFeaturedImage(draft.featuredImage);
        setAuthorName(draft.authorName);
        setAuthorRole(draft.authorRole);
        setAuthorImage(draft.authorImage);
        setReadTime(draft.readTime);
        setFeatures(draft.features);
        setTechnologies(draft.technologies);
        setHasDraft(true);
        
        toast({
          title: "Draft Loaded",
          description: "Your previous draft has been restored.",
        });
      } catch (error) {
        console.error('Error loading draft:', error);
      }
    }
  };
  
  const clearDraft = (postId: string | null) => {
    localStorage.removeItem(getDraftKey(postId));
    setHasDraft(false);
  };
  
  // Auto-save draft every 30 seconds and when editor state changes
  useEffect(() => {
    if (!isEditMode) return;
    
    const autoSaveTimer = setInterval(saveDraft, 30000);
    return () => clearInterval(autoSaveTimer);
  }, [isEditMode, title, content, excerpt, category, tags, featuredImage, 
      authorName, authorRole, authorImage, readTime, features, technologies]);
  
  // Save draft when user switches tabs or closes window
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden && isEditMode) {
        saveDraft();
      }
    };
    
    const handleBeforeUnload = () => {
      if (isEditMode) {
        saveDraft();
      }
    };
    
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleBeforeUnload);
    
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [isEditMode]);

  // Reset form when edit mode changes
  useEffect(() => {
    if (!isEditMode && selectedPost) {
      handleSelectPost(selectedPost);
    }
  }, [isEditMode]);
  
  const handleSelectPost = (post: ExtendedBlogPostType) => {
    if (!isEditMode && selectedPost?.id !== post.id) {
      toast({
        title: "Edit Mode Required",
        description: "Please enable edit mode to select a different post.",
        variant: "destructive",
      });
      return;
    }
    
    setSelectedPost(post);
    
    // Check for existing draft
    const draftKey = getDraftKey(post.id);
    const savedDraft = localStorage.getItem(draftKey);
    
    if (savedDraft) {
      loadDraft(post.id);
    } else {
      setTitle(post.title);
      setContent(post.content || "");
      setExcerpt(post.excerpt);
      setCategory(post.category);
      setTags(post.tags || []);
      setFeaturedImage(post.featuredImage || "");
      setAuthorName(post.authorName || "ASSAD");
      setAuthorRole(post.authorRole || "AI & Automation Expert");
      setAuthorImage(post.authorImage || "");
      setReadTime(post.readTime || "5 min read");
      setFeatures(post.features || []);
      setTechnologies(post.technologies || []);
      setHasDraft(false);
    }
  };
  
  const handleNewPost = () => {
    if (!isEditMode) {
      toast({
        title: "Edit Mode Required",
        description: "Please enable edit mode to create a new post.",
        variant: "destructive",
      });
      return;
    }
    
    setSelectedPost(null);
    
    // Check for existing draft for new post
    const draftKey = getDraftKey(null);
    const savedDraft = localStorage.getItem(draftKey);
    
    if (savedDraft) {
      loadDraft(null);
    } else {
      setTitle("");
      setContent("");
      setExcerpt("");
      setCategory(type === 'project' ? 'Project' : 'Technology');
      setTags([]);
      setFeaturedImage("");
      setAuthorName("ASSAD");
      setAuthorRole("AI & Automation Expert");
      setAuthorImage("");
      setReadTime("5 min read");
      setFeatures([]);
      setTechnologies([]);
      setHasDraft(false);
    }
  };
  
  const handleAddTag = () => {
    if (!isEditMode) return;
    
    if (tagInput && !tags.includes(tagInput)) {
      setTags([...tags, tagInput]);
      setTagInput("");
    }
  };
  
  const handleRemoveTag = (tagToRemove: string) => {
    if (!isEditMode) return;
    
    setTags(tags.filter(tag => tag !== tagToRemove));
  };
  
  const handleAddFeature = () => {
    if (!isEditMode) return;
    
    if (featureInput && !features.includes(featureInput)) {
      setFeatures([...features, featureInput]);
      setFeatureInput("");
    }
  };
  
  const handleRemoveFeature = (featureToRemove: string) => {
    if (!isEditMode) return;
    
    setFeatures(features.filter(feature => feature !== featureToRemove));
  };
  
  const handleAddTechnology = () => {
    if (!isEditMode) return;
    
    if (techInput && !technologies.includes(techInput)) {
      setTechnologies([...technologies, techInput]);
      setTechInput("");
    }
  };
  
  const handleRemoveTechnology = (techToRemove: string) => {
    if (!isEditMode) return;
    
    setTechnologies(technologies.filter(tech => tech !== techToRemove));
  };
  
  const handleSavePost = () => {
    if (!isEditMode) {
      toast({
        title: "Edit Mode Required",
        description: "Please enable edit mode to save changes.",
        variant: "destructive",
      });
      return;
    }
    
    if (!title) {
      toast({
        title: "Title Required",
        description: "Please enter a title for your post.",
        variant: "destructive",
      });
      return;
    }
    
    // Generate slug from title
    const baseSlug = generateSlug(title, type);
    
    // Get existing slugs excluding the current post
    const existingSlugs = blogPosts
      .filter(post => post.id !== selectedPost?.id)
      .map(post => post.id);
    
    // Ensure unique slug
    const uniqueSlug = ensureUniqueSlug(baseSlug, existingSlugs);
    
    const postToSave: ExtendedBlogPostType = {
      id: selectedPost ? selectedPost.id : uniqueSlug,
      title,
      content,
      excerpt,
      category,
      tags,
      date: selectedPost?.date || new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
      readTime,
      authorName,
      authorRole,
      authorImage,
      featuredImage,
      isDraft: false // Mark as published
      ,
      slug: "",
      status: "draft",
      createdAt: "",
      updatedAt: ""
    };
    
    // Add project-specific fields if this is a project
    if (type === 'project') {
      postToSave.features = features;
      postToSave.technologies = technologies;
      postToSave.imageUrl = featuredImage; // For backwards compatibility
    }
    
    saveBlogPost(postToSave);
    
    // Clear draft after successful save
    clearDraft(postToSave.id);
    setHasDraft(false);
    
    toast({
      title: "Post Published",
      description: "Your post has been published successfully.",
    });
  };
  
  const handleSaveDraft = () => {
    if (!isEditMode) return;
    
    // Save to localStorage first
    saveDraft();
    
    // Also save to main storage as a draft
    if (title) {
      const baseSlug = generateSlug(title, type);
      const existingSlugs = blogPosts
        .filter(post => post.id !== selectedPost?.id)
        .map(post => post.id);
      const uniqueSlug = ensureUniqueSlug(baseSlug, existingSlugs);
      
      const draftPost: ExtendedBlogPostType = {
        id: selectedPost ? selectedPost.id : uniqueSlug,
        title,
        content,
        excerpt,
        category,
        tags,
        date: selectedPost?.date || new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
        readTime,
        authorName,
        authorRole,
        authorImage,
        featuredImage,
        isDraft: true // Mark as draft
        ,
        slug: "",
        status: "draft",
        createdAt: "",
        updatedAt: ""
      };
      
      if (type === 'project') {
        draftPost.features = features;
        draftPost.technologies = technologies;
        draftPost.imageUrl = featuredImage;
      }
      
      saveBlogPost(draftPost);
    }
    
    toast({
      title: "Draft Saved",
      description: "Your draft has been saved. It will not be visible to visitors until published.",
    });
  };
  
  const handleDeletePost = (postId: string) => {
    if (!isEditMode) {
      toast({
        title: "Edit Mode Required",
        description: `Please enable edit mode to delete ${type}s.`,
        variant: "destructive",
      });
      return;
    }
    
    deleteBlogPost(postId);
    if (selectedPost && selectedPost.id === postId) {
      handleNewPost();
    }
    
    toast({
      title: `${type === 'project' ? 'Project' : 'Post'} Deleted`,
      description: `The ${type} has been deleted successfully.`,
      variant: "destructive",
    });
  };
  
  const renderPreview = () => {
    return (
      <div className="bg-white rounded-xl border p-6">
        <div className="prose prose-zinc max-w-none">
          {featuredImage && (
            <div className="mb-6">
              <img src={featuredImage} alt={title} className="w-full h-64 object-cover rounded-lg" />
            </div>
          )}
          
          <h1>{title || "Untitled"}</h1>
          
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="bg-zinc-100 px-3 py-1 rounded-full text-sm">{category}</span>
            {tags.map(tag => (
              <span key={tag} className="bg-zinc-100 px-3 py-1 rounded-full text-sm">{tag}</span>
            ))}
          </div>
          
          <div className="mb-6 text-zinc-600">
            <p className="italic">{excerpt}</p>
          </div>
          
          <div dangerouslySetInnerHTML={{ __html: content }} />
          
          {type === 'project' && (
            <>
              {features.length > 0 && (
                <div className="mt-8">
                  <h2>Key Features</h2>
                  <ul>
                    {features.map((feature, i) => (
                      <li key={i}>{feature}</li>
                    ))}
                  </ul>
                </div>
              )}
              
              {technologies.length > 0 && (
                <div className="mt-8">
                  <h2>Technologies Used</h2>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {technologies.map((tech, i) => (
                      <span key={i} className="bg-zinc-100 px-4 py-2 rounded-lg">{tech}</span>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    );
  };
  
  // Update the save button rendering to show both Save Draft and Publish options
  const renderSaveButtons = () => {
    return (
      <div className="flex gap-2">
        <Button
          onClick={handleSaveDraft}
          disabled={!isEditMode}
          variant="outline"
          className="flex-1 bg-white hover:bg-zinc-50 dark:bg-zinc-800 dark:hover:bg-zinc-700/70"
        >
          <Save size={16} className="mr-2" />
          Save Draft
        </Button>
        <Button
          onClick={handleSavePost}
          disabled={!isEditMode}
          variant="default"
          className="flex-1 bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-white">
          <Check size={16} className="mr-2" />
          Publish
        </Button>
      </div>
    );
  };
  
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1">
        <Card className="bg-white dark:bg-zinc-800/50">
          <CardHeader>
            <CardTitle className="flex justify-between items-center">
              <span>{type === 'project' ? 'Projects' : 'Blog Posts'}</span>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={handleNewPost}
                disabled={!isEditMode}
                className="bg-white hover:bg-zinc-50 dark:bg-zinc-800 dark:hover:bg-zinc-700/70"
              >
                <Plus size={16} className="mr-1" /> New {type === 'project' ? 'Project' : 'Post'}
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {filteredPosts.map(post => (
                <div 
                  key={post.id} 
                  className={`p-3 border rounded-lg cursor-pointer flex justify-between items-center ${
                    selectedPost && selectedPost.id === post.id ? 'bg-zinc-100 border-zinc-300' : 'border-zinc-200 hover:bg-zinc-50'
                  }`}
                  onClick={() => handleSelectPost(post)}
                >
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-sm truncate">{post.title}</h3>
                    <p className="text-xs text-zinc-500 truncate">{post.excerpt.substring(0, 50)}...</p>
                  </div>
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeletePost(post.id);
                    }}
                    disabled={!isEditMode}
                  >
                    <Trash2 size={16} className={isEditMode ? "text-zinc-500 hover:text-red-500" : "text-zinc-300"} />
                  </Button>
                </div>
              ))}
              
              {filteredPosts.length === 0 && (
                <div className="text-center p-4 text-zinc-500">
                  No {type === 'project' ? 'projects' : 'blog posts'} yet
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="lg:col-span-2">
        <Tabs value={editorMode} onValueChange={(value) => setEditorMode(value as 'edit' | 'preview')}>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">
              {selectedPost 
                ? `Edit ${type === 'project' ? 'Project' : 'Blog Post'}` 
                : `New ${type === 'project' ? 'Project' : 'Blog Post'}`}
            </h2>
            <TabsList>
              <TabsTrigger value="edit" className="flex items-center gap-1">
                <Edit size={16} /> Edit
              </TabsTrigger>
              <TabsTrigger value="preview" className="flex items-center gap-1">
                <Eye size={16} /> Preview
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="edit">
            <Card className="bg-white dark:bg-zinc-800/50">
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="post-title">Title</Label>
                    <Input 
                      id="post-title" 
                      value={title} 
                      onChange={(e) => setTitle(e.target.value)} 
                      placeholder={`Enter ${type} title`}
                      disabled={!isEditMode}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="post-excerpt">Excerpt / Short Description</Label>
                    <Textarea 
                      id="post-excerpt" 
                      value={excerpt} 
                      onChange={(e) => setExcerpt(e.target.value)} 
                      placeholder="Brief summary of your content"
                      disabled={!isEditMode}
                      rows={3}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="post-category">Category</Label>
                      <Input 
                        id="post-category" 
                        value={category} 
                        onChange={(e) => setCategory(e.target.value)} 
                        placeholder="E.g. Technology, AI, etc."
                        disabled={type === 'project' || !isEditMode}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="post-read-time">Read Time</Label>
                      <Input 
                        id="post-read-time" 
                        value={readTime} 
                        onChange={(e) => setReadTime(e.target.value)} 
                        placeholder="E.g. 5 min read"
                        disabled={!isEditMode}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="post-tags">Tags</Label>
                    <div className="flex gap-2">
                      <Input 
                        id="post-tags" 
                        value={tagInput} 
                        onChange={(e) => setTagInput(e.target.value)} 
                        placeholder="Add a tag" 
                        className="flex-1"
                        disabled={!isEditMode}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && isEditMode) {
                            e.preventDefault();
                            handleAddTag();
                          }
                        }}
                      />
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={handleAddTag}
                        disabled={!isEditMode}
                      >
                        <Plus size={16} />
                      </Button>
                    </div>
                    
                    {tags.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-2">
                        {tags.map(tag => (
                          <span 
                            key={tag} 
                            className="bg-zinc-100 text-zinc-700 px-2 py-1 rounded-full text-xs flex items-center gap-1"
                          >
                            {tag}
                            <button 
                              type="button" 
                              className={isEditMode ? "text-zinc-500 hover:text-red-500" : "text-zinc-300"}
                              onClick={() => handleRemoveTag(tag)}
                              disabled={!isEditMode}
                            >
                              <Trash2 size={12} />
                            </button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="post-featured-image">Featured Image URL</Label>
                    <div className="flex gap-2">
                      <Input 
                        id="post-featured-image" 
                        value={featuredImage} 
                        onChange={(e) => setFeaturedImage(e.target.value)} 
                        placeholder="URL to featured image"
                        disabled={!isEditMode}
                        className="flex-1"
                      />
                      {featuredImage && (
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => window.open(featuredImage, '_blank')}
                          size="icon"
                        >
                          <LinkIcon size={16} />
                        </Button>
                      )}
                    </div>
                    
                    {featuredImage && (
                      <div className="mt-2">
                        <img 
                          src={featuredImage} 
                          alt="Featured" 
                          className="h-20 object-cover rounded" 
                        />
                      </div>
                    )}
                  </div>
                  
                  {type === 'project' && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="project-features">Features</Label>
                        <div className="flex gap-2">
                          <Input 
                            id="project-features" 
                            value={featureInput} 
                            onChange={(e) => setFeatureInput(e.target.value)} 
                            placeholder="Add a feature" 
                            className="flex-1"
                            disabled={!isEditMode}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && isEditMode) {
                                e.preventDefault();
                                handleAddFeature();
                              }
                            }}
                          />
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={handleAddFeature}
                            disabled={!isEditMode}
                          >
                            <Plus size={16} />
                          </Button>
                        </div>
                        
                        {features.length > 0 && (
                          <ul className="mt-2 space-y-2">
                            {features.map((feature, index) => (
                              <li 
                                key={index} 
                                className="flex justify-between items-center bg-zinc-50 p-2 rounded border border-zinc-100"
                              >
                                <span>{feature}</span>
                                <button 
                                  type="button" 
                                  className={isEditMode ? "text-zinc-500 hover:text-red-500" : "text-zinc-300"}
                                  onClick={() => handleRemoveFeature(feature)}
                                  disabled={!isEditMode}
                                >
                                  <Trash2 size={16} />
                                </button>
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="project-technologies">Technologies</Label>
                        <div className="flex gap-2">
                          <Input 
                            id="project-technologies" 
                            value={techInput} 
                            onChange={(e) => setTechInput(e.target.value)} 
                            placeholder="Add a technology" 
                            className="flex-1"
                            disabled={!isEditMode}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && isEditMode) {
                                e.preventDefault();
                                handleAddTechnology();
                              }
                            }}
                          />
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={handleAddTechnology}
                            disabled={!isEditMode}
                          >
                            <Plus size={16} />
                          </Button>
                        </div>
                        
                        {technologies.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-2">
                            {technologies.map((tech, index) => (
                              <span 
                                key={index} 
                                className="bg-zinc-100 text-zinc-700 px-2 py-1 rounded-md text-sm flex items-center gap-1"
                              >
                                {tech}
                                <button 
                                  type="button" 
                                  className={isEditMode ? "text-zinc-500 hover:text-red-500" : "text-zinc-300"}
                                  onClick={() => handleRemoveTechnology(tech)}
                                  disabled={!isEditMode}
                                >
                                  <Trash2 size={12} />
                                </button>
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="post-content">Content</Label>
                    <RichTextEditor 
                      value={content} 
                      onChange={setContent} 
                      placeholder={`Write your ${type} content here...`}
                      readOnly={!isEditMode}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="post-author">Author Name</Label>
                      <Input 
                        id="post-author" 
                        value={authorName} 
                        onChange={(e) => setAuthorName(e.target.value)} 
                        placeholder="Author name"
                        disabled={!isEditMode}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="post-author-role">Author Role</Label>
                      <Input 
                        id="post-author-role" 
                        value={authorRole} 
                        onChange={(e) => setAuthorRole(e.target.value)} 
                        placeholder="Author role or title"
                        disabled={!isEditMode}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="post-author-image">Author Image URL</Label>
                    <Input 
                      id="post-author-image" 
                      value={authorImage} 
                      onChange={(e) => setAuthorImage(e.target.value)} 
                      placeholder="URL to author's profile image"
                      disabled={!isEditMode}
                    />
                    
                    {authorImage && (
                      <div className="mt-2">
                        <img 
                          src={authorImage} 
                          alt="Author" 
                          className="h-16 w-16 rounded-full object-cover" 
                        />
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={handleNewPost}
                  className="bg-white hover:bg-zinc-50 dark:bg-zinc-800 dark:hover:bg-zinc-700/70"
                >
                  Cancel
                </Button>
                {renderSaveButtons()}
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="preview">
            <Card className="bg-white dark:bg-zinc-800/50">
              <CardContent>
                {renderPreview()}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default BlogEditor;
