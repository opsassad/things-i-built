import { useState } from "react";
import { 
  Upload, 
  Trash2, 
  Copy, 
  Pencil,
  Check,
  X,
  Loader
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { toast } from "../../hooks/use-toast";
import { useContent } from "../../context/ContentContext";
import { getPublicMediaUrl } from '@/lib/supabaseClient';

const ImageManager = () => {
  const { mediaLibrary, uploadMedia, deleteMedia, updateMediaName, isEditMode } = useContent();
  const [editingImage, setEditingImage] = useState<string | null>(null);
  const [editedName, setEditedName] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isEditMode) {
      toast({
        title: "Edit Mode Required",
        description: "Please enable edit mode to upload images.",
        variant: "destructive",
      });
      return;
    }
    
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      setSelectedFile(file);
      
      try {
        setIsUploading(true);

        // We need file info for the upload function
        const fileInfo = {
          name: file.name,
          size: `${(file.size / 1024).toFixed(2)} KB`, // Calculate size
          type: file.type
        }
        
        // The uploadMedia function in ContentContext now handles storage directly
        // It expects an object with name, url (as data/blob), size, type
        const dataUrl = await fileToDataUrl(file); // Need to convert to data URL for the upload function

        const uploadedMedia = await uploadMedia({
          name: fileInfo.name,
          url: dataUrl, 
          size: fileInfo.size,
          type: fileInfo.type
        });
        
        // No need to check for fallback here, uploadMedia handles DB insertion
        toast({
          title: "Image Uploaded",
          description: "Your image has been uploaded successfully.",
          variant: "default",
        });
        
        setIsUploading(false);
        setSelectedFile(null);
        
        // Reset the file input
        const fileInput = document.getElementById('image-upload') as HTMLInputElement;
        if (fileInput) fileInput.value = '';

      } catch (error: any) {
        console.error('Error uploading file', error);
        setIsUploading(false);
        setSelectedFile(null);
        
        toast({
          title: "Upload Failed",
          description: error.message || "There was an error uploading your image.",
          variant: "destructive",
        });
         // Reset the file input on failure too
        const fileInput = document.getElementById('image-upload') as HTMLInputElement;
        if (fileInput) fileInput.value = '';
      }
    }
  };
  
  const handleDeleteImage = async (id: string) => {
    if (!isEditMode) {
      toast({
        title: "Edit Mode Required",
        description: "Please enable edit mode to delete images.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      await deleteMedia(id);
      toast({
        title: "Image Deleted",
        description: "The image has been deleted successfully.",
        variant: "destructive",
      });
    } catch (error) {
      console.error('Error deleting image', error);
      toast({
        title: "Delete Failed",
        description: "There was an error deleting the image.",
        variant: "destructive",
      });
    }
  };
  
  const handleCopyUrl = (url: string) => {
    // Transform the URL to the masked version before copying
    const maskedUrl = getPublicMediaUrl(url);
    
    // Use absolute URL with origin for proper copying from any location
    const absoluteUrl = window.location.origin + maskedUrl;
    
    navigator.clipboard.writeText(absoluteUrl);
    toast({
      title: "URL Copied",
      description: "Masked image URL copied to clipboard.",
      variant: "default",
    });
  };
  
  const startEditingImage = (id: string, name: string) => {
    if (!isEditMode) {
      toast({
        title: "Edit Mode Required",
        description: "Please enable edit mode to rename images.",
        variant: "destructive",
      });
      return;
    }
    
    setEditingImage(id);
    setEditedName(name);
  };
  
  const saveImageName = async (id: string) => {
    try {
      await updateMediaName(id, editedName);
      setEditingImage(null);
      toast({
        title: "Image Renamed",
        description: "The image has been renamed successfully.",
        variant: "default",
      });
    } catch (error) {
      console.error('Error renaming image', error);
      toast({
        title: "Rename Failed",
        description: "There was an error renaming the image.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <Card className="bg-white dark:bg-zinc-800/50">
      <CardHeader>
        <CardTitle>Media Library</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <Label htmlFor="image-upload" className="block mb-2">Upload New Image</Label>
          <div className="flex flex-col sm:flex-row gap-2">
            <Input 
              id="image-upload" 
              type="file" 
              accept="image/*" 
              onChange={handleImageUpload} 
              className="flex-1" 
              disabled={!isEditMode || isUploading}
            />
            <Button 
              type="button"
              disabled={!isEditMode || isUploading}
              onClick={() => document.getElementById('image-upload')?.click()}
              className="w-full sm:w-auto bg-white hover:bg-zinc-50 dark:bg-zinc-800 dark:hover:bg-zinc-700/70"
              variant="outline"
            >
              {isUploading ? (
                <>
                  <Loader size={16} className="mr-1 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload size={16} className="mr-1" />
                  Upload
                </>
              )}
            </Button>
          </div>
          {selectedFile && isUploading && (
            <div className="mt-2 text-sm text-zinc-500">
              Uploading {selectedFile.name}...
            </div>
          )}
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {mediaLibrary.map((image) => {
            // Use getPublicMediaUrl to transform the URL before displaying
            const displayUrl = getPublicMediaUrl(image.url);
            // console.log('[ImageManager] Using proxied URL for', image.name, ':', displayUrl); // Optional log

            return (
              <div key={image.id} className="relative group border rounded-lg overflow-hidden aspect-square">
                {displayUrl ? (
                  <img
                    src={displayUrl} // Use the transformed (proxied) URL
                    alt={image.name}
                    className="object-cover w-full h-full"
                    onError={(e) => {
                      // Log error if proxied image fails to load
                      console.error('[ImageManager] Image failed to load proxied URL:', displayUrl, 'for image:', image.name, e);
                    }}
                  />
                ) : (
                  <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                    <span className="text-gray-500 text-sm">Invalid URL</span>
                  </div>
                )}
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="flex gap-2">
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className="text-white hover:bg-white/20"
                      onClick={() => handleCopyUrl(image.url)}
                    >
                      <Copy size={16} />
                    </Button>
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className="text-white hover:bg-white/20"
                      onClick={() => startEditingImage(image.id, image.name)}
                      disabled={!isEditMode}
                    >
                      <Pencil size={16} />
                    </Button>
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className={`text-white ${isEditMode ? "hover:bg-red-500/40" : "opacity-50 cursor-not-allowed"}`}
                      onClick={() => handleDeleteImage(image.id)}
                      disabled={!isEditMode}
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        {mediaLibrary.length === 0 && (
          <div className="text-center p-8 border border-dashed rounded-lg text-zinc-500 bg-zinc-50/50 dark:bg-zinc-800/30">
            No images uploaded yet
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Need fileToDataUrl utility function here or imported correctly
const fileToDataUrl = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export default ImageManager;
