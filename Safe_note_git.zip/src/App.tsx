import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "./components/ui/toaster";
import Index from "./pages/Index";
import ProjectsPage from "./pages/ProjectsPage";
import ThoughtsPage from "./pages/ThoughtsPage";
import BlogPost from "./pages/BlogPost";
import AboutPage from "./pages/AboutPage";
import ContactPage from "./pages/ContactPage";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfService from "./pages/TermsOfService";
import NotFound from "./pages/NotFound";
import AdminPage from "./pages/AdminPage";
import { ContentProvider } from "./context/ContentContext";
import ExamplePage from './pages/ExamplePage';

function App() {
  return (
    <ContentProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/projects" element={<ProjectsPage />} />
          <Route path="/thoughts" element={<ThoughtsPage />} />
          <Route path="/thoughts/:slug" element={<BlogPost />} />
          <Route path="/projects/:slug" element={<BlogPost />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/terms-of-service" element={<TermsOfService />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/blog" element={<Navigate to="/thoughts" replace />} />
          <Route path="/blog/:slug" element={<BlogPost />} />
          <Route path="/examples" element={<ExamplePage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Toaster />
      </BrowserRouter>
    </ContentProvider>
  );
}

export default App;
