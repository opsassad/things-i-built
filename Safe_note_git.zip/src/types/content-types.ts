// Extended BlogPostType to include project-specific fields
export interface ExtendedBlogPostType {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string[];
  date: string;
  readTime: string;
  authorName: string;
  authorRole: string;
  technologies?: string[];
  features?: string[];
  detailedDescription?: string;
  imageUrl?: string;
  featuredImage?: string;
  authorImage?: string;
  link?: string;
  isDraft?: boolean;
  slug: string;
  status: 'draft' | 'published' | 'archived';
  createdAt: string;
  updatedAt: string;
  viewCount?: number;
  likeCount?: number;
  seoScore?: number;
}

export interface SiteSettings {
  siteTitle: string;
  siteDescription: string;
  githubUrl: string;
  linkedinUrl: string;
  twitterUrl: string;
  enableComments: boolean;
  enableAnalytics: boolean;
  // SMTP Settings
  smtpHost?: string;
  smtpPort?: string;
  smtpUsername?: string;
  smtpPassword?: string;
  smtpFromEmail?: string;
  smtpFromName?: string;
  smtpEncryption?: 'tls' | 'ssl' | 'none';
}

export interface ViewStats {
  date: string;
  views: number;
}

export interface ContentStats {
  title: string;
  views: number;
  likes: number;
  category: string;
}

export interface ActivityLog {
  type: 'edit' | 'publish' | 'draft' | 'view';
  content: string;
  time: string;
  userId?: string;
}

// Add MediaItem type
export type MediaItem = {
  id: string;
  name: string;
  url: string;
  size: string;
  type: string;
  date: string;
  bucket?: string;
  path?: string;
};

// Add HomePageContent type definition
export interface HomePageContent {
  heroTitle: string;
  heroSubtitle: string;
  aboutText: string;
}
