import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { 
  Eye, 
  Pencil, 
  Save, 
  FileText, 
  ImagePlus, 
  Tag, 
  Settings,
  Check,
  Briefcase,
  Clock,
  RefreshCcw,
  BookOpen,
  LayoutDashboard,
  Mail
} from "lucide-react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { Button } from "../components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Label } from "../components/ui/label";
import { Switch } from "../components/ui/switch";
import { toast } from "../hooks/use-toast";
import { Badge } from "../components/ui/badge";
import BlogEditor from "../components/admin/BlogEditor";
import ImageManager from "../components/admin/ImageManager";
import DashboardAnalytics from "../components/admin/DashboardAnalytics";
import { useContent } from "../context/ContentContext";

const AdminPage = () => {
  const { 
    isEditMode, 
    setEditMode, 
    homePageContent, 
    updateHomePageContent,
    siteSettings,
    updateSiteSettings,
    blogPosts,
    saveBlogPost
  } = useContent();
  
  const [activeTab, setActiveTab] = useState("content");
  const [pendingHomeContent, setPendingHomeContent] = useState(() => homePageContent);
  const [pendingSiteSettings, setPendingSiteSettings] = useState(() => siteSettings);
  const [hasDraft, setHasDraft] = useState(() => {
    return localStorage.getItem('draftHomeContent') !== null || localStorage.getItem('draftSiteSettings') !== null;
  });
  
  // For switching blog editor mode (regular blog vs project)
  const [blogEditorMode, setBlogEditorMode] = useState<'blog' | 'project'>('blog');
  
  const [pendingSMTPSettings, setPendingSMTPSettings] = useState({
    host: siteSettings.smtpHost || '',
    port: siteSettings.smtpPort || '587',
    username: siteSettings.smtpUsername || '',
    password: siteSettings.smtpPassword || '',
    fromEmail: siteSettings.smtpFromEmail || '',
    fromName: siteSettings.smtpFromName || '',
    encryption: siteSettings.smtpEncryption || 'tls'
  });
  
  // Update pending content when Supabase data changes
  useEffect(() => {
    console.log("Updating pending content from homePageContent:", homePageContent);
    setPendingHomeContent(homePageContent);
    
    // Clear any stale drafts on initial load to prevent them from overriding fresh Supabase data
    const savedDraftContent = localStorage.getItem('draftHomeContent');
    if (savedDraftContent) {
      // Check if the draft is older than the Supabase data
      // For simplicity, just clear it on page load when Supabase data is available
      localStorage.removeItem('draftHomeContent');
      setHasDraft(prevHasDraft => {
        // Only update hasDraft if this was the only draft
        const hasSiteSettingsDraft = localStorage.getItem('draftSiteSettings') !== null;
        return hasSiteSettingsDraft;
      });
    }
  }, [homePageContent]);
  
  // Update pending settings when Supabase data changes
  useEffect(() => {
    console.log("Updating pending settings from siteSettings:", siteSettings);
    setPendingSiteSettings(siteSettings);
    // Also update SMTP settings
    setPendingSMTPSettings({
      host: siteSettings.smtpHost || '',
      port: siteSettings.smtpPort || '587',
      username: siteSettings.smtpUsername || '',
      password: siteSettings.smtpPassword || '',
      fromEmail: siteSettings.smtpFromEmail || '',
      fromName: siteSettings.smtpFromName || '',
      encryption: siteSettings.smtpEncryption || 'tls'
    });
    
    // Clear any stale drafts on initial load
    const savedDraftSettings = localStorage.getItem('draftSiteSettings');
    if (savedDraftSettings) {
      localStorage.removeItem('draftSiteSettings');
      setHasDraft(prevHasDraft => {
        // Only update hasDraft if this was the only draft
        const hasHomeContentDraft = localStorage.getItem('draftHomeContent') !== null;
        return hasHomeContentDraft;
      });
    }
  }, [siteSettings]);
  
  const toggleEditMode = () => {
    setEditMode(!isEditMode);
    toast({
      title: isEditMode ? "View Mode Activated" : "Edit Mode Activated",
      description: isEditMode 
        ? "You're now viewing the site as visitors would see it." 
        : "You can now edit site content.",
      variant: "default",
    });
  };
  
  const handleSaveDraft = () => {
    // Save the current pending changes to localStorage but don't publish
    localStorage.setItem('draftHomeContent', JSON.stringify(pendingHomeContent));
    localStorage.setItem('draftSiteSettings', JSON.stringify(pendingSiteSettings));
    
    setHasDraft(true);
    
    toast({
      title: "Draft Saved",
      description: "Your changes have been saved as a draft.",
      variant: "default",
    });
  };
  
  const handleLoadDraft = () => {
    const savedDraftContent = localStorage.getItem('draftHomeContent');
    const savedDraftSettings = localStorage.getItem('draftSiteSettings');
    
    if (savedDraftContent) {
      setPendingHomeContent(JSON.parse(savedDraftContent));
    }
    
    if (savedDraftSettings) {
      setPendingSiteSettings(JSON.parse(savedDraftSettings));
    }
    
    toast({
      title: "Draft Loaded",
      description: "Your draft has been loaded.",
      variant: "default",
    });
  };
  
  const handlePublish = () => {
    // Update the actual content
    updateHomePageContent(pendingHomeContent);
    updateSiteSettings(pendingSiteSettings);
    
    // Clear drafts after publishing
    localStorage.removeItem('draftHomeContent');
    localStorage.removeItem('draftSiteSettings');
    setHasDraft(false);
    
    toast({
      title: "Changes Published",
      description: "Your changes are now live on the site.",
      variant: "default",
    });
  };
  
  const handleContentChange = (field: keyof typeof pendingHomeContent, value: string) => {
    setPendingHomeContent(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSettingsChange = (field: keyof typeof pendingSiteSettings, value: any) => {
    setPendingSiteSettings(prev => ({ ...prev, [field]: value }));
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow pt-24 pb-16 bg-zinc-50 dark:bg-zinc-900">
        <div className="container-custom max-w-6xl">
          <div className="mb-8 space-y-4 sm:space-y-0 sm:flex sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl sm:text-3xl font-display font-bold text-zinc-700 dark:text-zinc-100">Admin Dashboard</h1>
              <Badge variant={isEditMode ? "default" : "outline"} className={isEditMode ? "bg-amber-500 hover:bg-amber-600 dark:bg-amber-600 dark:hover:bg-amber-700" : ""}>
                {isEditMode ? "Edit Mode" : "View Mode"}
              </Badge>
            </div>
            
            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
              <Button 
                variant="outline" 
                className={`flex items-center gap-2 bg-white hover:bg-zinc-50 dark:bg-zinc-800 dark:hover:bg-zinc-700/70`}
                onClick={toggleEditMode}
              >
                {isEditMode ? <Eye size={16} /> : <Pencil size={16} />}
                {isEditMode ? "View Mode" : "Edit Mode"}
              </Button>
              
              {isEditMode && (
                <>
                  <Button 
                    variant="outline" 
                    className="flex items-center gap-2 bg-white hover:bg-zinc-50 dark:bg-zinc-800 dark:hover:bg-zinc-700/70"
                    onClick={handleSaveDraft}
                  >
                    <Clock size={16} />
                    Save Draft
                  </Button>
                  
                  {hasDraft && (
                    <Button 
                      variant="outline" 
                      className="flex items-center gap-2 bg-white hover:bg-zinc-50 dark:bg-zinc-800 dark:hover:bg-zinc-700/70"
                      onClick={handleLoadDraft}
                    >
                      <RefreshCcw size={16} />
                      Load Draft
                    </Button>
                  )}
                  
                  <Button 
                    variant="default" 
                    className="flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-white"
                    onClick={handlePublish}
                  >
                    <Check size={16} />
                    Publish
                  </Button>
                </>
              )}
            </div>
          </div>
          
          <Tabs defaultValue="dashboard" onValueChange={setActiveTab} value={activeTab} className="space-y-4">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-1 bg-zinc-100 dark:bg-zinc-800/50 p-1 rounded-lg">
              <TabsTrigger 
                value="dashboard" 
                className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-900 data-[state=active]:text-zinc-900 dark:data-[state=active]:text-zinc-50 data-[state=active]:shadow-sm"
              >
                <LayoutDashboard size={16} />
                Dashboard
              </TabsTrigger>
              <TabsTrigger 
                value="content" 
                className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-900 data-[state=active]:text-zinc-900 dark:data-[state=active]:text-zinc-50 data-[state=active]:shadow-sm"
              >
                <FileText size={16} />
                Content
              </TabsTrigger>
              <TabsTrigger 
                value="blog" 
                onClick={() => setBlogEditorMode('blog')} 
                className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-900 data-[state=active]:text-zinc-900 dark:data-[state=active]:text-zinc-50 data-[state=active]:shadow-sm"
              >
                <BookOpen size={16} />
                Blog Posts
              </TabsTrigger>
              <TabsTrigger 
                value="projects" 
                onClick={() => setBlogEditorMode('project')} 
                className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-900 data-[state=active]:text-zinc-900 dark:data-[state=active]:text-zinc-50 data-[state=active]:shadow-sm"
              >
                <Briefcase size={16} />
                Projects
              </TabsTrigger>
              <TabsTrigger 
                value="media" 
                className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-900 data-[state=active]:text-zinc-900 dark:data-[state=active]:text-zinc-50 data-[state=active]:shadow-sm"
              >
                <ImagePlus size={16} />
                Media
              </TabsTrigger>
              <TabsTrigger 
                value="settings" 
                className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-900 data-[state=active]:text-zinc-900 dark:data-[state=active]:text-zinc-50 data-[state=active]:shadow-sm"
              >
                <Settings size={16} />
                Settings
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="dashboard" className="mt-6">
              <DashboardAnalytics />
            </TabsContent>
            
            <TabsContent value="content" className="mt-6">
              <Card className="bg-white dark:bg-zinc-800/50">
                <CardHeader>
                  <CardTitle>Edit Website Content</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Home Page</h3>
                      <div className="grid gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="hero-title">Hero Title</Label>
                          <Input 
                            id="hero-title" 
                            value={pendingHomeContent.heroTitle}
                            onChange={(e) => handleContentChange('heroTitle', e.target.value)}
                            disabled={!isEditMode}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="hero-subtitle">Hero Subtitle</Label>
                          <Textarea 
                            id="hero-subtitle" 
                            value={pendingHomeContent.heroSubtitle}
                            onChange={(e) => handleContentChange('heroSubtitle', e.target.value)}
                            disabled={!isEditMode}
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">About Section</h3>
                      <div className="grid gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="about-text">About Text</Label>
                          <Textarea 
                            id="about-text" 
                            rows={5} 
                            value={pendingHomeContent.aboutText}
                            onChange={(e) => handleContentChange('aboutText', e.target.value)}
                            disabled={!isEditMode}
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-end">
                      {isEditMode && (
                        <div className="flex gap-2">
                          <Button 
                            variant="outline"
                            className="flex items-center gap-2"
                            onClick={handleSaveDraft}
                          >
                            <Clock size={16} />
                            Save Draft
                          </Button>
                          <Button 
                            className="flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-white"
                            onClick={handlePublish}
                          >
                            <Check size={16} />
                            Publish Changes
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="blog" className="mt-6">
              <BlogEditor type="blog" />
            </TabsContent>
            
            <TabsContent value="projects" className="mt-6">
              <BlogEditor type="project" />
            </TabsContent>
            
            <TabsContent value="media" className="mt-6">
              <ImageManager />
            </TabsContent>
            
            <TabsContent value="settings" className="mt-6">
              <div className="grid gap-6">
                <Card className="bg-white dark:bg-zinc-800/50">
                  <CardHeader>
                    <CardTitle>Website Settings</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">SEO Settings</h3>
                        <div className="grid gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="site-title">Site Title</Label>
                            <Input 
                              id="site-title" 
                              value={pendingSiteSettings.siteTitle}
                              onChange={(e) => handleSettingsChange('siteTitle', e.target.value)}
                              disabled={!isEditMode}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="site-description">Site Description</Label>
                            <Textarea 
                              id="site-description" 
                              value={pendingSiteSettings.siteDescription}
                              onChange={(e) => handleSettingsChange('siteDescription', e.target.value)}
                              disabled={!isEditMode}
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Social Media</h3>
                        <div className="grid gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="github-url">GitHub URL</Label>
                            <Input 
                              id="github-url" 
                              type="url" 
                              value={pendingSiteSettings.githubUrl}
                              onChange={(e) => handleSettingsChange('githubUrl', e.target.value)}
                              disabled={!isEditMode}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="linkedin-url">LinkedIn URL</Label>
                            <Input 
                              id="linkedin-url" 
                              type="url" 
                              value={pendingSiteSettings.linkedinUrl}
                              onChange={(e) => handleSettingsChange('linkedinUrl', e.target.value)}
                              disabled={!isEditMode}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="twitter-url">Twitter URL</Label>
                            <Input 
                              id="twitter-url" 
                              type="url" 
                              value={pendingSiteSettings.twitterUrl}
                              onChange={(e) => handleSettingsChange('twitterUrl', e.target.value)}
                              disabled={!isEditMode}
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Visibility Settings</h3>
                        <div className="flex items-center space-x-2">
                          <Switch 
                            id="comments-enabled" 
                            checked={pendingSiteSettings.enableComments}
                            onCheckedChange={(checked) => handleSettingsChange('enableComments', checked)}
                            disabled={!isEditMode}
                          />
                          <Label htmlFor="comments-enabled">Enable Blog Comments</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch 
                            id="analytics-enabled" 
                            checked={pendingSiteSettings.enableAnalytics}
                            onCheckedChange={(checked) => handleSettingsChange('enableAnalytics', checked)}
                            disabled={!isEditMode}
                          />
                          <Label htmlFor="analytics-enabled">Enable Analytics</Label>
                        </div>
                      </div>
                      
                      <div className="flex justify-end">
                        {isEditMode && (
                          <div className="flex gap-2">
                            <Button 
                              variant="outline"
                              className="flex items-center gap-2"
                              onClick={handleSaveDraft}
                            >
                              <Clock size={16} />
                              Save Draft
                            </Button>
                            <Button 
                              className="flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-white"
                              onClick={handlePublish}
                            >
                              <Check size={16} />
                              Publish Settings
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                {/* SMTP Settings */}
                <Card className="bg-white dark:bg-zinc-800/50">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Mail className="h-5 w-5 text-muted-foreground" />
                      <CardTitle>SMTP Settings</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="smtp-host">SMTP Host</Label>
                          <Input
                            id="smtp-host"
                            placeholder="smtp.example.com"
                            value={pendingSMTPSettings.host}
                            onChange={(e) => setPendingSMTPSettings(prev => ({
                              ...prev,
                              host: e.target.value
                            }))}
                            disabled={!isEditMode}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="smtp-port">SMTP Port</Label>
                          <Input
                            id="smtp-port"
                            placeholder="587"
                            value={pendingSMTPSettings.port}
                            onChange={(e) => setPendingSMTPSettings(prev => ({
                              ...prev,
                              port: e.target.value
                            }))}
                            disabled={!isEditMode}
                          />
                        </div>
                      </div>

                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="smtp-username">Username</Label>
                          <Input
                            id="smtp-username"
                            placeholder="your-email@example.com"
                            value={pendingSMTPSettings.username}
                            onChange={(e) => setPendingSMTPSettings(prev => ({
                              ...prev,
                              username: e.target.value
                            }))}
                            disabled={!isEditMode}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="smtp-password">Password</Label>
                          <Input
                            id="smtp-password"
                            type="password"
                            value={pendingSMTPSettings.password}
                            onChange={(e) => setPendingSMTPSettings(prev => ({
                              ...prev,
                              password: e.target.value
                            }))}
                            disabled={!isEditMode}
                          />
                        </div>
                      </div>

                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="from-email">From Email</Label>
                          <Input
                            id="from-email"
                            placeholder="noreply@yourdomain.com"
                            value={pendingSMTPSettings.fromEmail}
                            onChange={(e) => setPendingSMTPSettings(prev => ({
                              ...prev,
                              fromEmail: e.target.value
                            }))}
                            disabled={!isEditMode}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="from-name">From Name</Label>
                          <Input
                            id="from-name"
                            placeholder="Your Site Name"
                            value={pendingSMTPSettings.fromName}
                            onChange={(e) => setPendingSMTPSettings(prev => ({
                              ...prev,
                              fromName: e.target.value
                            }))}
                            disabled={!isEditMode}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Encryption</Label>
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-2">
                            <input
                              type="radio"
                              id="tls"
                              name="encryption"
                              value="tls"
                              checked={pendingSMTPSettings.encryption === 'tls'}
                              onChange={(e) => setPendingSMTPSettings(prev => ({
                                ...prev,
                                encryption: e.target.value as 'tls' | 'ssl' | 'none'
                              }))}
                              disabled={!isEditMode}
                              className="text-primary"
                            />
                            <Label htmlFor="tls">TLS</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input
                              type="radio"
                              id="ssl"
                              name="encryption"
                              value="ssl"
                              checked={pendingSMTPSettings.encryption === 'ssl'}
                              onChange={(e) => setPendingSMTPSettings(prev => ({
                                ...prev,
                                encryption: e.target.value as 'tls' | 'ssl' | 'none'
                              }))}
                              disabled={!isEditMode}
                              className="text-primary"
                            />
                            <Label htmlFor="ssl">SSL</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input
                              type="radio"
                              id="none"
                              name="encryption"
                              value="none"
                              checked={pendingSMTPSettings.encryption === 'none'}
                              onChange={(e) => setPendingSMTPSettings(prev => ({
                                ...prev,
                                encryption: e.target.value as 'tls' | 'ssl' | 'none'
                              }))}
                              disabled={!isEditMode}
                              className="text-primary"
                            />
                            <Label htmlFor="none">None</Label>
                          </div>
                        </div>
                      </div>

                      {isEditMode && (
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            className="flex items-center gap-2 bg-white hover:bg-zinc-50 dark:bg-zinc-800 dark:hover:bg-zinc-700/70"
                            onClick={() => {
                              // Test SMTP connection
                              toast({
                                title: "Testing SMTP Connection",
                                description: "Please wait...",
                              });
                            }}
                          >
                            <RefreshCcw className="h-4 w-4" />
                            Test Connection
                          </Button>
                          <Button
                            className="flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-white"
                            onClick={() => {
                              // Save SMTP settings
                              updateSiteSettings({
                                ...siteSettings,
                                smtpHost: pendingSMTPSettings.host,
                                smtpPort: pendingSMTPSettings.port,
                                smtpUsername: pendingSMTPSettings.username,
                                smtpPassword: pendingSMTPSettings.password,
                                smtpFromEmail: pendingSMTPSettings.fromEmail,
                                smtpFromName: pendingSMTPSettings.fromName,
                                smtpEncryption: pendingSMTPSettings.encryption,
                              });
                              toast({
                                title: "SMTP Settings Saved",
                                description: "Your email settings have been updated.",
                              });
                            }}
                          >
                            <Save className="h-4 w-4" />
                            Save Settings
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AdminPage;
