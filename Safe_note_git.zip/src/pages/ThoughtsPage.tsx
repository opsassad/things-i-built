import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { useContent } from "../context/ContentContext";

const MotionLink = motion(Link);

// Format date to be more readable (e.g., "May 3, 2025" instead of ISO string)
const formatDate = (dateString) => {
  if (!dateString) return '';
  
  try {
    const date = new Date(dateString);
    // Check if date is valid
    if (isNaN(date.getTime())) return dateString;
    
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  } catch (error) {
    console.error("Error formatting date:", error);
    return dateString; // Return original string if there's an error
  }
};

const ThoughtsPage = () => {
  const { blogPosts } = useContent();
  
  // Filter only blog posts (exclude projects)
  const thoughtPosts = blogPosts.filter(post => 
    post.category === "Blog" || post.id.startsWith('blog/')
  );

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      <main className="flex-grow pt-32 pb-24">
        <motion.div 
          className="max-w-3xl mx-auto px-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.h1 
            className="text-3xl font-light mb-12 text-zinc-800"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Thoughts
          </motion.h1>
          
          {/* Blog Posts Grid */}
          <motion.div 
            className="space-y-16"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            {thoughtPosts.map((post, index) => (
              <motion.article 
                key={post.id} 
                className="group"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 0.6,
                  delay: 0.2 * (index + 1),
                  ease: [0.23, 1, 0.32, 1]
                }}
              >
                {(post.featuredImage || post.imageUrl) && (
                  <MotionLink 
                    to={`/thoughts/${post.id.split('/').slice(1).join('/')}`}
                    className="block mb-6 aspect-[2/1] overflow-hidden rounded-xl"
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
                  >
                    <motion.img 
                      src={post.featuredImage || post.imageUrl} 
                      alt={post.title}
                      className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity"
                      initial={{ scale: 1.1 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}
                    />
                  </MotionLink>
                )}
                
                <div className="space-y-4">
                  <motion.div 
                    className="text-sm text-zinc-400"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.4, delay: 0.2 * (index + 2) }}
                  >
                    {formatDate(post.date)} · {post.readTime}
                  </motion.div>
                  
                  <motion.h2 
                    className="text-xl text-zinc-800"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.4, delay: 0.2 * (index + 2.2) }}
                  >
                    <Link 
                      to={`/thoughts/${post.id.split('/').slice(1).join('/')}`}
                      className="hover:text-zinc-600 transition-colors"
                    >
                      {post.title}
                    </Link>
                  </motion.h2>
                  
                  <motion.p 
                    className="text-zinc-600 leading-relaxed"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.4, delay: 0.2 * (index + 2.4) }}
                  >
                    {post.excerpt}
                  </motion.p>
                  
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.4, delay: 0.2 * (index + 3) }}
                  >
                    <MotionLink
                      to={`/thoughts/${post.id.split('/').slice(1).join('/')}`}
                      className="inline-flex items-center text-zinc-800 hover:text-zinc-600 transition-colors text-sm"
                      whileHover={{ x: 4 }}
                      transition={{ duration: 0.2 }}
                    >
                      Read more
                      <ArrowRight size={16} className="ml-1" />
                    </MotionLink>
                  </motion.div>
                </div>
              </motion.article>
            ))}
          </motion.div>
          
          {thoughtPosts.length === 0 && (
            <motion.div 
              className="text-zinc-400 text-center py-16"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              No thoughts published yet.
            </motion.div>
          )}
        </motion.div>
      </main>
      <Footer />
    </div>
  );
};

export default ThoughtsPage; 