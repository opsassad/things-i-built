import { useState, useEffect } from "react";
import { ArrowRight, Plus } from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { useContent } from "../context/ContentContext";

const MotionLink = motion(Link);

// Format date to be more readable (e.g., "May 3, 2025" instead of ISO string)
const formatDate = (dateString) => {
  if (!dateString) return '';
  
  try {
    const date = new Date(dateString);
    // Check if date is valid
    if (isNaN(date.getTime())) return dateString;
    
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  } catch (error) {
    console.error("Error formatting date:", error);
    return dateString; // Return original string if there's an error
  }
};

const ProjectsPage = () => {
  const { blogPosts } = useContent();
  
  // Filter only project posts
  const projectPosts = blogPosts.filter(post => 
    post.category === "Project" || post.id.startsWith('project/')
  );

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      <main className="flex-grow pt-32 pb-24">
        <motion.div 
          className="max-w-3xl mx-auto px-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.h1 
            className="text-3xl font-light mb-12 text-zinc-800"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Git & Grit
          </motion.h1>
          
          {/* Projects Grid */}
          <motion.div 
            className="space-y-24"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            {projectPosts.map((post, index) => (
              <motion.article 
                key={post.id} 
                className="group"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 0.6,
                  delay: 0.2 * (index + 1),
                  ease: [0.23, 1, 0.32, 1]
                }}
              >
                {(post.featuredImage || post.imageUrl) && (
                  <MotionLink 
                    to={`/projects/${post.id.split('/').slice(1).join('/')}`}
                    className="block mb-8 aspect-[2/1] overflow-hidden rounded-2xl"
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
                  >
                    <motion.img 
                      src={post.featuredImage || post.imageUrl} 
                      alt={post.title}
                      className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity"
                      initial={{ scale: 1.1 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}
                    />
                  </MotionLink>
                )}
                
                <div className="space-y-6">
                  <div className="space-y-4">
                    <motion.div 
                      className="text-sm text-zinc-400"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.4, delay: 0.2 * (index + 2) }}
                    >
                      {formatDate(post.date)} · {post.readTime}
                    </motion.div>
                    
                    <motion.h2 
                      className="text-xl text-zinc-800"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.4, delay: 0.2 * (index + 2.2) }}
                    >
                      <Link 
                        to={`/projects/${post.id.split('/').slice(1).join('/')}`}
                        className="hover:text-zinc-600 transition-colors"
                      >
                        {post.title}
                      </Link>
                    </motion.h2>
                    
                    <motion.p 
                      className="text-zinc-600 leading-relaxed"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.4, delay: 0.2 * (index + 2.4) }}
                    >
                      {post.excerpt}
                    </motion.p>
                  </div>

                  {/* Features Section */}
                  {post.features && post.features.length > 0 && (
                    <motion.div 
                      className="space-y-2"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.4, delay: 0.2 * (index + 2.6) }}
                    >
                      <h3 className="text-sm font-medium text-zinc-800">Features</h3>
                      <div className="flex flex-wrap gap-2">
                        {post.features.map((feature, i) => (
                          <span 
                            key={i}
                            className="inline-flex items-center text-xs text-zinc-600 border border-zinc-200 rounded-full px-3 py-1"
                          >
                            <Plus size={12} className="mr-1" />
                            {feature}
                          </span>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {/* Technologies Section */}
                  {post.technologies && post.technologies.length > 0 && (
                    <motion.div 
                      className="space-y-2"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.4, delay: 0.2 * (index + 2.8) }}
                    >
                      <h3 className="text-sm font-medium text-zinc-800">Technologies</h3>
                      <div className="flex flex-wrap gap-2">
                        {post.technologies.map((tech, i) => (
                          <span 
                            key={i}
                            className="inline-flex items-center text-xs text-zinc-600 bg-zinc-50 rounded-full px-3 py-1"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </motion.div>
                  )}
                  
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.4, delay: 0.2 * (index + 3) }}
                  >
                    <MotionLink
                      to={`/projects/${post.id.split('/').slice(1).join('/')}`}
                      className="inline-flex items-center text-zinc-800 hover:text-zinc-600 transition-colors text-sm"
                      whileHover={{ x: 4 }}
                      transition={{ duration: 0.2 }}
                    >
                      Read more
                      <ArrowRight size={16} className="ml-1" />
                    </MotionLink>
                  </motion.div>
                </div>
              </motion.article>
            ))}
          </motion.div>
          
          {projectPosts.length === 0 && (
            <motion.div 
              className="text-zinc-400 text-center py-16"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              No projects found.
            </motion.div>
          )}
        </motion.div>
      </main>
      <Footer />
    </div>
  );
};

export default ProjectsPage;
