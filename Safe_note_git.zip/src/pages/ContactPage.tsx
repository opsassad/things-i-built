import { useState } from "react";
import { useToast } from "../hooks/use-toast";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

const ContactPage = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // --- Actual API Call --- 
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || 'Failed to send message. Please try again.');
      }
      // --- End API Call --- 

      toast({
        title: "Message sent",
        // Use API success message if available
        description: result.message || "Thank you for your message. I'll get back to you soon.", 
      });
      
      // Reset form
      setFormData({
        name: "",
        email: "",
        message: "",
      });
      
    } catch (error: any) {
      console.error("Contact form submission error:", error);
      toast({
        title: "Error",
        description: error.message || "Could not send message. Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      <main className="flex-grow pt-32 pb-24">
        <div className="max-w-2xl mx-auto px-6">
          <h1 className="text-3xl font-light mb-12 text-zinc-800">Contact</h1>
          
          <form onSubmit={handleSubmit} className="space-y-8">
            <div>
              <label htmlFor="name" className="block text-sm text-zinc-600 mb-2">
                Name
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-0 py-3 bg-transparent border-0 border-b border-zinc-200 focus:border-zinc-400 focus:ring-0 text-zinc-800"
                placeholder="Your name"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm text-zinc-600 mb-2">
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-0 py-3 bg-transparent border-0 border-b border-zinc-200 focus:border-zinc-400 focus:ring-0 text-zinc-800"
                placeholder="your@email.com"
              />
            </div>
            
            <div>
              <label htmlFor="message" className="block text-sm text-zinc-600 mb-2">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={4}
                className="w-full px-0 py-3 bg-transparent border-0 border-b border-zinc-200 focus:border-zinc-400 focus:ring-0 text-zinc-800 resize-none"
                placeholder="What's on your mind?"
              ></textarea>
            </div>
            
            <div className="pt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className="text-zinc-800 hover:text-zinc-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? "Sending..." : "Send message"}
              </button>
            </div>
          </form>

          <div className="mt-24 text-zinc-500 text-sm">
            <p>You can also reach me at <a href="mailto:contact@example.com" className="text-zinc-800 hover:text-zinc-600 transition-colors">contact@example.com</a></p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ContactPage;
